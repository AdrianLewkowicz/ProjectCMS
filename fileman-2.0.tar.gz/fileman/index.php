<?
// This is a part of FileMan
//FileMan is free software; you can redistribute it and/or modify
//it under the terms of the GNU General Public License as published by
//the Free Software Foundation; either version 2 of the License, or
//(at your option) any later version.
//
//This program is distributed in the hope that it will be useful,
//but WITHOUT ANY WARRANTY; without even the implied warranty of
//MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//GNU General Public License for more details.
//
//You should have received a copy of the GNU General Public License
//along with this program; if not, write to the Free Software
//Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

include("config.php");
include("lang/$language.language.php");
include("inc/class.navigator.php");
include("inc/class.upload.php");

if($_GET['browse']!="") $base=urldecode($_GET['browse']);
$obj= new Navigator($base);
$obj->SortListD($_GET['sortby'],$_GET['sortdir']);
$obj->SortListF($_GET['sortby'],$_GET['sortdir']);

if (!empty($_POST['folder'])) {
	$obj->Create("d" ,$_POST['dir']."/".$_POST['klasor_adi']);
	header('LOCATION:'.$_SERVER['HTTP_REFERER']);
}

if (!empty($_POST['perm_kont'])) {
	$dir=$_POST['pwd']."/";
	$file=$_POST['file'];
	$perm=$_POST['perm'];

	$perm_new=eregi_replace("-","0",$perm);
	$perm_new=eregi_replace("r","1",$perm_new);
	$perm_new=eregi_replace("w","1",$perm_new);
	$perm_new=eregi_replace("x","1",$perm_new);

	$obj->ChgPerms($dir.$file,$perm_new);
	header('LOCATION:'.$_SERVER['HTTP_REFERER']);

}

if (!empty($_POST['delete_kont'])) {
	$dir=$_POST['pwd']."/";
	$file=$_POST['file'];

	$obj->Remove($dir.$file);;
	header('LOCATION:'.$_SERVER['HTTP_REFERER']);

}

if (!empty($_POST['dosyaadi_kont'])) {
	$dir=$_POST['pwd']."/";
	$file_old=$_POST['eski_adi'];
	$file_new=$_POST['yeni_adi'];

	$obj->Rename($dir.$file_old,$dir.$file_new);
	header('LOCATION:'.$_SERVER['HTTP_REFERER']);

}

if (!empty($_POST['delete_fold_kont'])) {
	$dir=$_POST['pwd']."/";
	$file=$_POST['file'];

	$obj->RemoveDir($dir.$file);;
	header('LOCATION:'.$_SERVER['HTTP_REFERER']);

}

if ($_POST['action'] == 'multiple') {
	$files = array();
	foreach ($_FILES['my_field'] as $k => $l) {
		foreach ($l as $i => $v) {
			if (!array_key_exists($i, $files))
			$files[$i] = array();
			$files[$i][$k] = $v;
		}
	}

	foreach ($files as $file) {

		$handle = new Upload($file);

		if ($handle->uploaded) {
			$handle->Process($_POST['dir']);
			if ($handle->processed) {
				header('LOCATION:'.$_SERVER['HTTP_REFERER']);
			} else {
				echo '<fieldset>';
				echo '  <legend>'.$lang['dosyahata01'].'</legend>';
				echo '  Error: ' . $handle->error . '';
				echo '</fieldset>';
			}
		} else {
			echo '<fieldset>';
			echo '  <legend>'.$lang['dosyahata01'].'</legend>';
			echo '  Error: ' . $handle->error . '';
			echo '</fieldset>';
		}
	}
}

?>
<html>
<head>
<title>FileMan v2.0</title>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<meta name="AUTHOR" content="Murat Küçükosman">
	<meta name="publisher" content="Murat Küçükosman with SF.net">
	<meta name="copyright" content="2006 © Copyright, Murat Küçükosman">
	<link rel="stylesheet" href="style/default.css" type="text/css">
</head>
<body>
<table border="0" cellpadding="0" cellspacing="0" height="100%" width="100%" class="out_border">
<tr>
	<td>

<table border="0" cellpadding="1" cellspacing="1" width="100%" height="100%" class="general_border">
	<tr>
		<th width="100%" colspan="2" valign="top" class="general_th">FileMan</th />
	</tr>
	<tr>
		<td class="general_td"><a href="javascript:void(history.back(-1))" class="dir_list"><-| <?=$lang['geri']?></a></td>
		<td class="general_td"><?=$obj->Pwd()?></td>

	</tr>
	<tr>
		<td width="30%"  valign="top" height="100%" class="general_td">
<?
$dir_gost.="<table border=0 width=100% cellpadding=4 cellspacing=0 class=\"dir_list\">";
$dir_gost.="<tr><td colspan=2>".$lang['toplam'].":".$obj->Count("d")."</td></tr>";
while($obj->NextDir())
{
	$dir_gost.="<tr>";
	$dir_gost.="<td><a href=\"$_SERVER[PHP_SELF]?browse=".urlencode($base."/$obj->FieldName")."\" class=\"dir_list\">$obj->FieldName</a></td>";
	$dir_gost.="
<form action=\"\" method=\"post\">
	<input type=\"hidden\" name=\"delete_kont\" value=\"degistir\">
	<input type=\"hidden\" name=\"pwd\" value=\"".$obj->Pwd()."\">
	<input type=\"hidden\" name=\"file\" value=\"".$obj->FieldName."\">
<td><input type=\"submit\" name=\"sil\" value=\"".$lang['sil']."\"></td></form>";
	$dir_gost.="</tr>";
}
$dir_gost.="</table>";
echo $dir_gost;
?>
		</td>
		<td width="70%"  valign="top"  height="100%" class="general_td">
		
<?



echo "<table border=0 cellpadding=4 cellspacing=0 width=100% class=\"file_list\">";
echo "<tr><td colspan=6>".$lang['toplam']." :".$obj->Count("f")."</td></tr>";
while($obj->NextFile())
{
	echo "<tr>";
	echo "<form action=\"\" method=\"post\"><td>
		<input type=\"hidden\" name=\"dosyaadi_kont\" value=\"degistir\">
		<input type=\"hidden\" name=\"pwd\" value=\"".$obj->Pwd()."\">
		<input type=\"hidden\" name=\"eski_adi\" value=\"".$obj->FieldName."\">
	<input class=\"dosya_adi\" type=\"text\" name=\"yeni_adi\" value=\"".$obj->FieldName."\">
	</td><td>
	<input type=\"submit\" value=\"".$lang['degistir']."\">
	</td>
	</form>";
	echo "<td>".$obj->FieldDate."</td>";
	echo "<td>".$obj->FieldSize."</td>";
	echo "<form action=\"\" method=\"post\">
		<input type=\"hidden\" name=\"perm_kont\" value=\"degistir\">
		<input type=\"hidden\" name=\"pwd\" value=\"".$obj->Pwd()."\">
		<input type=\"hidden\" name=\"file\" value=\"".$obj->FieldName."\">
		<td><input type=\"text\" class=\"perm_in\" name=\"perm\" value=\"".substr($obj->FieldPerms,1,9)."\" size=\"9\"  maxlength=\"9\">
		&nbsp;<input type=\"submit\" name=\"sup\" value=\"".$lang['degistir']."\"></td>
	</form>";
	echo "
<form action=\"\" method=\"post\">
		<input type=\"hidden\" name=\"delete_kont\" value=\"degistir\">
		<input type=\"hidden\" name=\"pwd\" value=\"".$obj->Pwd()."\">
		<input type=\"hidden\" name=\"file\" value=\"".$obj->FieldName."\">
<td><input type=\"submit\" name=\"sil\" value=\"".$lang['sil']."\"></td></form>";
	echo "</tr>";
}
echo "</table>";
?>
		</td>
	</tr>
	<tr>
		<td valign="top" class="general_td">
		<form action="" method="POST">
		<input type="hidden" name="folder" value="ekle">
		<b><?=$lang['klasorekle']?>:</b><br>
		<input type="text" name="klasor_adi" value="" class="file_opt"><input type="submit" value="<?=$lang['ekle']?>">
		<input type="hidden" name="dir" value="<?=$obj->Pwd()?>">
		</form>
		</td>
		<td valign="top" class="general_td"><b><?=$lang['dosyaekle']?>:</b><br>
        <form name="form" enctype="multipart/form-data" method="post" action="">
        <input type="hidden" name="action" value="multiple" />
		<input type="file" name="my_field[]" value="" class="file_opt"><br>
		<input type="file" name="my_field[]" value="" class="file_opt"><br>
		<input type="file" name="my_field[]" value="" class="file_opt"><br>
		<input type="file" name="my_field[]" value="" class="file_opt"><br>
		<input type="file" name="my_field[]" value="" class="file_opt"><br>
		<input type="hidden" name="dir" value="<?=$obj->Pwd()?>">
		<input type="submit" value="<?=$lang['gonder']?>">
		</form>
		</td>
	</tr>
	
</table>
	</td>
</tr>
</table><br>

<div id="imza">® 2006 Murat Küçükosman<br><br>
This General Public License does not permit incorporating your program into
proprietary programs.  If your program is a subroutine library, you may
consider it more useful to permit linking proprietary applications with the
library.  If this is what you want to do, use the GNU Lesser General
Public License instead of this License.
</div>
</body>
</html>