<?
#Lang: Turkce
$lang['sil'] = "Sil";
$lang['degistir']="Değiştir";
$lang['toplam']="Toplam";
$lang['klasorekle']="Klasör Ekle";
$lang['dosyaekle']="Dosya Ekle";
$lang['gonder']="Gönder";
$lang['ekle']="Ekle";
$lang['geri']="Geri";

$lang['dosyahata01']="Dosya İstenilen Yere Yüklenemedi";
$lang['hata01']="Yanlış Klasör Adı<br>Config.php dosyasını kontrol edin.";
$lang['hata02']="Ovf.. imtiyazları değiştirirken problem oldu.<br>dosya sahibini kontrol et.";
$lang['hata03']="mevcut";
$lang['hata04']="mevcut değil";
$lang['hata05']="Dosyayı Oluşturamadım";
$lang['hata06']="Klasörü Oluşturamadım";
$lang['hata07']="Dosyayı Silemedim";
$lang['hata08']="Klasörü Silemedim";
$lang['hata09']="Dosya hatası lütfen sonra tekrar deneyin.";
?>