<?
#Lang: English
$lang['sil'] = "Delete";
$lang['degistir']="Modify";
$lang['toplam']="Total";
$lang['klasorekle']="Add Folder";
$lang['dosyaekle']="Upload File(s)";
$lang['gonder']="Upload";
$lang['ekle']="Add";
$lang['geri']="Back";

$lang['dosyahata01']="Dosya İstenilen Yere Yüklenemedi";
$lang['hata01']="Yanlış Klasör Adı<br>Config.php dosyasını kontrol edin.";
$lang['hata02']="Ovf.. imtiyazları değiştirirken problem oldu.<br>dosya sahibini kontrol et.";
$lang['hata03']="mevcut";
$lang['hata04']="mevcut değil";
$lang['hata05']="Dosyayı Oluşturamadım";
$lang['hata06']="Klasörü Oluşturamadım";
$lang['hata07']="Dosyayı Silemedim";
$lang['hata08']="Klasörü Silemedim";
$lang['hata09']="Dosya hatası lütfen sonra tekrar deneyin.";
?>