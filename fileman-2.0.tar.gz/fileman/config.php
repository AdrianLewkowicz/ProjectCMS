<?
#config.php

$base="../"; //Browsing Folder
$language="tr"; //now supporting en (english),tr (turkish)
?>