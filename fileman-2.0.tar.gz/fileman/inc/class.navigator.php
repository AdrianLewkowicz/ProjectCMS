<?
// This is a part of FileMan
//FileMan is free software; you can redistribute it and/or modify
//it under the terms of the GNU General Public License as published by
//the Free Software Foundation; either version 2 of the License, or
//(at your option) any later version.
//
//This program is distributed in the hope that it will be useful,
//but WITHOUT ANY WARRANTY; without even the implied warranty of
//MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//GNU General Public License for more details.
//
//You should have received a copy of the GNU General Public License
//along with this program; if not, write to the Free Software
//Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
class Navigator
{

	var $GetDirSz=false ;  // Directory boyutunu görmek için.
	var $DateFormat = "d-m-Y H:i:s" ; // Son değişim zamanı için zaman fonksyonu
	##############################################

	var $Curdir   ;
	var $DirsList  =  array("Name" =>array(),"DateM"=>array(),"Size" =>array(),
	"Perms"=>array(),"Owner"=>array(),"Group"=>array() );
	var $FilesList =  array("Name" =>array(),"DateM"=>array(),"Size" =>array(),
	"Perms"=>array(),"Owner"=>array(),"Group"=>array() );
	var $Handle;
	var $ErrMess;
	var $Path;
	var $OrderArrD =array();
	var $OrderArrF =array();
	var $PointerPosD;
	var $PointerPosF;


	var $FieldName;
	var $FieldDate;
	var $FieldSize;
	var $FieldPerms;
	var $FieldOwner;
	var $FieldGroup;


	function Navigator($parm,$sort_filed="N",$dir="ASC")
	{
		global $lang;
		if(!isset($parm)) $parm = "." ;
		if(is_dir($parm)) $this->CurDir = $parm ;
		else $this->Err($lang['hata01']);

		chdir($this->CurDir);
		$this->Handle=opendir(".");
		$this->LoadList()  ;
		$this->SortListF($sort_filed,$dir);
		$this->SortListD($sort_filed,$dir);
		$this->PointerPosF=0;
		$this->PointerPosD=0;
		closedir($this->Handle);
	}

	function LoadList()
	{
		$tmp=0;
		while($file = readdir($this->Handle))
		{
			if(is_dir($file) && $file!="." && $file!="..")
			{
				$this->DirsList["Name"][]  = $file;
				$this->DirsList["DateM"][] = $this->LastUpdate($file);
				$this->DirsList["Size"][]  = ($this->GetDirSz) ? $this->GetDirSize($file) : '' ;
				$this->DirsList["Perms"][] = $this->GetPerms($file);
				$this->DirsList["Owner"][] = fileowner($file);
				$this->DirsList["Group"][] = filegroup($file);
			}
			elseif(is_file($file) && $file!="." && $file!="..")
			{
				$this->FilesList["Name"][]  = $file;
				$this->FilesList["DateM"][] = $this->LastUpdate($file);
				$this->FilesList["Size"][]  = filesize($file);
				$this->FilesList["Perms"][] = $this->GetPerms($file);
				$this->FilesList["Owner"][] = fileowner($file);
				$this->FilesList["Group"][] = filegroup($file);
			}
			$tmp++;
		}
	}


	/*
	* imtiyazların -rwxr-xr-- şekline çevrilmesi
	*/
	function GetPerms($file)
	{
		switch (filetype ($file)){
			case "dir"   ;$ret2="d"; break;
			case "fifo"  ;$ret2="f"; break;
			case "char"  ;$ret2="c"; break;
			case "block" ;$ret2="b"; break;
			case "link"  ;$ret2="l"; break;
			case "file"  ;$ret2="-"; break;
			default      :$ret2="-"; break;
		}
		$ret=sprintf("%b", (fileperms($file)) & 0777);
		( $ret[0]) ? ($ret2.="r") : ($ret2.="-");
		( $ret[1]) ? ($ret2.="w") : ($ret2.="-");
		( $ret[2]) ? ($ret2.="x") : ($ret2.="-");
		( $ret[3]) ? ($ret2.="r") : ($ret2.="-");
		( $ret[4]) ? ($ret2.="w") : ($ret2.="-");
		( $ret[5]) ? ($ret2.="x") : ($ret2.="-");
		( $ret[6]) ? ($ret2.="r") : ($ret2.="-");
		( $ret[7]) ? ($ret2.="w") : ($ret2.="-");
		( $ret[8]) ? ($ret2.="x") : ($ret2.="-");
		return $ret2;
	}


	function LastUpdate($file)
	{
		return date($this->DateFormat,filemtime($file));
	}

	function NextFile()
	{
		if(isset($this->OrderArrF))
		{
			$keyz= array_keys($this->OrderArrF) ;

			if(isset($this->OrderArrF[$keyz[$this->PointerPosF]]))
			{
				$this->FieldName  =$this->FilesList["Name"][$this->OrderArrF[$keyz[$this->PointerPosF]]] ;
				$this->FieldDate  =$this->FilesList["DateM"][$this->OrderArrF[$keyz[$this->PointerPosF]]];
				$this->FieldSize  =$this->ConvertSize($this->FilesList["Size"][$this->OrderArrF[$keyz[$this->PointerPosF]]]);
				$this->FieldPerms =$this->FilesList["Perms"][$this->OrderArrF[$keyz[$this->PointerPosF]]];
				$this->FieldOwner =$this->FilesList["Owner"][$this->OrderArrF[$keyz[$this->PointerPosF]]];
				$this->FieldGroup =$this->FilesList["Group"][$this->OrderArrF[$keyz[$this->PointerPosF]]];
				$this->PointerPosF++;
				return true;
			}else return false;
		}
		else { return false; }
	}

	function NextDir()
	{

		if( isset($this->OrderArrD))
		{
			$keyz= array_keys($this->OrderArrD) ;

			if(isset($this->OrderArrD[$keyz[$this->PointerPosD]]))
			{
				$this->FieldName  =$this->DirsList["Name"][$this->OrderArrD[$keyz[$this->PointerPosD]]] ;
				$this->FieldDate  =$this->DirsList["DateM"][$this->OrderArrD[$keyz[$this->PointerPosD]]];
				$this->FieldSize  = ($this->GetDirSz) ? $this->ConvertSize($this->DirsList["Size"][$this->OrderArrD[$keyz[$this->PointerPosD]]]) : '';
				$this->FieldPerms =$this->DirsList["Perms"][$this->OrderArrD[$keyz[$this->PointerPosD]]];
				$this->FieldOwner =$this->DirsList["Owner"][$this->OrderArrD[$keyz[$this->PointerPosD]]];
				$this->FieldGroup =$this->DirsList["Group"][$this->OrderArrD[$keyz[$this->PointerPosD]]];
				$this->PointerPosD++;
				return true;
			}else return false;
		}
		else { return false; }
	}

	function SortListF($what,$direction="ASC")
	{
		unset($this->OrderArrF);

		switch($what)
		{
			case "D" ; //Date
			$i = 0;
			reset($this->FilesList["DateM"]);
			while($i<count($this->FilesList["DateM"])){
				$tmp=explode(' ',$this->FilesList["DateM"][$i]);
				$key1= split('-', $tmp[0]);
				$key2= split(':', $tmp[1]);

				$key=mktime ($key2[0],$key2[1],$key2[2],$key1[1],$key1[0],$key1[2]) ;
				$this->OrderArrF[$key.'.'.$i] = $i;
				$i++;
			}

			if($direction=="ASC" and isset($this->OrderArrF) )ksort($this->OrderArrF) ;
			elseif( isset($this->OrderArrF)) krsort($this->OrderArrF) ;

			
			break;

			case "S"; //Size
			$i = 0;
			reset($this->FilesList["Size"]);
			while($i<count($this->FilesList["Size"])){
				$this->OrderArrF[$this->FilesList["Size"][$i].'.'.$i] = $i;
				$i++;
			}

			if($direction=="ASC"  and isset($this->OrderArrF))ksort($this->OrderArrF) ;
			elseif(  isset($this->OrderArrF)) krsort($this->OrderArrF) ;

			
			break;

			default:

				$i = 0;
				reset($this->FilesList["Name"]);
				while($i<count($this->FilesList["Name"])){
					$this->OrderArrF[strtolower($this->FilesList["Name"][$i])] = $i;   // küçük harfe çevirir
					$i++;
				}

				if($direction=="ASC"  and isset($this->OrderArrF))ksort($this->OrderArrF) ;
				elseif(  isset($this->OrderArrF)) krsort($this->OrderArrF) ;

				break;

		}
	}

	function SortListD($what,$direction="ASC")
	{

		unset($this->OrderArrD);

		switch($what)
		{
			case "D" ; //Date
			$i = 0;
			reset($this->DirsList["DateM"]);
			while (list($key, $val) = each($this->DirsList["DateM"])) {
				$tmp=explode(' ',$this->DirsList["DateM"][$i]);
				$key1= split( '-', $tmp[0]);
				$key2= split( ':', $tmp[1]);

				$key=mktime ($key2[0],$key2[1],$key2[2],$key1[1],$key1[0],$key1[2]) ;
				$this->OrderArrD[$key.'.'.$i] = $i;
				$i++;
			}

			if($direction=="ASC"  and isset($this->OrderArrD))ksort($this->OrderArrD) ;
			elseif( isset($this->OrderArrD)) krsort($this->OrderArrD) ;

			break;

			case "S"; //Size
			$i = 0;
			reset($this->DirsList["Size"]);
			while($i<count($this->DirsList["Size"])){
				$this->OrderArrD[$this->DirsList["Size"][$i].'.'.$i] = $i;
				$i++;
			}

			if($direction=="ASC"  and isset($this->OrderArrD))ksort($this->OrderArrD) ;
			elseif( isset($this->OrderArrD)) krsort($this->OrderArrD) ;
			break;

			default:

				$i = 0;
				reset($this->DirsList["Name"]);
				while($i<count($this->DirsList["Name"])){
					$this->OrderArrD[strtolower($this->DirsList["Name"][$i])] = $i;
					$i++;
				}

				if($direction=="ASC"  and isset($this->OrderArrD))ksort($this->OrderArrD) ;
				elseif( isset($this->OrderArrD)) krsort($this->OrderArrD) ;

				break;
		}
	}


	function Count($what="")
	{
		switch($what)
		{case "d": return count($this->DirsList["Name"]);break;
			case "f": return count($this->FilesList["Name"]);break;
			default: return  count($this->DirsList["Name"])+count($this->FilesList["Name"]);break;
		}
	}


	function Pwd()
	{
		return realpath(".");
	}

	function ChgPerms($file,$perms='111100100') //rwxrwxrwx
	{
		$dec =bindec ($perms);
		$oct =decoct ($dec);
		if(!chmod( $file, '0'.octdec($oct) )) $this->Err("Ovf.. imtiyazları değiştirirken problem oldu.<br>dosya sahibini kontrol et.");
	}



	function GetDirSize($dir)
	{
		$dossier=opendir($dir);
		$total=0;
		while ($fichier = readdir($dossier))
		{
			$l = array('.', '..');
			if (!in_array( $fichier, $l))
			{
				if (is_dir($dir."/".$fichier))
				{
					$total += $this->GetDirSize($dir."/".$fichier);
				}
				else
				{
					$total+=filesize($dir."/".$fichier);
				}
			}
		}
		return $total;
	}

	function Rename($old,$new)
	{
		if (file_exists($old))
		{
			if(!file_exists($new)) rename($old,$new);
			else $this->Err("$new mevcut !");
		}
		else $this->Err("$old mevcut değil !");
	}


	function Create($what,$name)
	{
		global $lang;
		switch($what)
		{
			case "f";
			if (!file_exists($name))
			{if(!$fp=fopen($name,"w")) $this->Err($lang['hata05']." : $name") ;
			else fclose($fp);
			}else  $this->Err($name." ".$lang['hata03']." !");
			break;
			case "d";
			if (!file_exists($name))
			{if(!mkdir ($name, 0700)){ $this->Err($lang['hata06']." : $name");}
			}else  {$this->Err($new." ".$lang['hata03']." !"); }
			break;
		}
	}

	/*
	* remove a file
	*/
	function Remove($file)
	{
		global $lang;
		if(!@unlink($file)) $this->Err($lang['hata07']." : $file");
	}


	/*
	* remove directory (recursive)
	*/
	function RemoveDir($dir)
	{
		global $lang;
		if($handle=@opendir($dir))
		{
			while ($file=readdir($handle))
			{
				if (is_dir($dir."/".$file) && $file !=".." && $file!="." )
				{
					$this->RemoveDir($dir."/".$file);
					if (file_exists($dir."/".$file))
					{
						rmdir($dir."/".$file);
					}
				}
				else
				{
					if (is_file($dir."/".$file) && file_exists($dir."/".$file))
					{
						unlink($dir."/".$file);
					}
				}
			}
			closedir($handle);
			rmdir($dir);
		}
		else $this->Err($lang['hata08']." : $dir") ;
	}



	/*
	* convert size to KB, MB, GB
	*/
	function ConvertSize($sz)
	{
		if ($sz >= 1073741824)  {$sz = round($sz / 1073741824 * 100) / 100 . " GB";}
		elseif ($sz >= 1048576) {$sz = round($sz / 1048576 * 100)    / 100 . " MB";}
		elseif ($sz >= 1024)    {$sz = round($sz / 1024 * 100)       / 100 . " KB";}
		else                    {$sz = $sz . " Byte";}

		return $sz;
	}


	/*
	* Stop execution with error message
	*/
	function Err($mess)
	{
		$this->ErrMess = $mess;
		echo "<font color=red>$mess</font><br>";
		exit;
	}

}
?>
